BLINKY-8 for the PDP-8 and PiDP-8
=================================

BLINKY-8 is a program designed to show off the PDP-8 front-panel by
using the switch register to display varying patterns in the lamps.
As an aside, it uses most of the PDP-8 instruction-set and programming
methods (e.g. subroutines, interrupts, and auto-indexing).

This archive contains the following files:

- ReadMe.txt   This file
- BLINKY8.txt  SIMH batch file to load, list, and/or, run BLINKY-8
- BLINKY8.ptp  PDP-8 paper tape binary image of BLINKY-8
- BLINKY8.pdf  Formatted BLINKY-8 listing (in PDF format)
- B8.PA.txt    OS/8 PAL8 octal source code for BLINKY8.ptp

After reading this file, also read the comments at the top of BLINKY8.txt.
These explain in detail what BLINKY-8 is all about.

If you want to run BLINKY-8 on a physical PDP-8, you will almost certainly
need to change some of the code.  Use B8.PA as the basis for BLINKY-8 and
make the necessary changes at the bottom.  There are a number of comments
about necessary changes for a physical PDP-8 in BLINKY8.txt.

Usage on the PiDP-8:

	sim> ; Set up realcons as usual
	sim> do BLINKY8.txt

	-or-

	sim> load BLINKY8.ptp
	sim> run 0200

Have fun!

Mike Hill, 11th February 2020.
